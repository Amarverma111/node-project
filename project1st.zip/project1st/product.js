const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const productSchema = new Schema({
  username: {
    type: String,
    required: true,
  },
      email: {
    type:String,
    required: true,
  },
  district: {
    type:String,
    required: true,
  },
  
  phonenumber: {
    type: int,
    required: true,
  },
  
   state: {
    type: String,
    required: true,
  },
  
  address: {
    type: string,
    required: true,
  },
});

module.exports = mongoose.model("Product", productSchema);