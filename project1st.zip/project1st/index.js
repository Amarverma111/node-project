
var mongoose = require("mongoose");
var LoginRoutes = require("./submit");
var SubmitRoutes = require("./fashion");
var express = require("express");
var bodyParser = require("body-parser");

var path = require("path");

var app = express(); 
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use("/fashion", adminRoutes);
app.use(storeRoutes);

app.use(express.static(path.join(__dirname, "./index")));

app.use((req, res, next) => {
  res.render("404", {
    title: "Page Not Found",
  });
});

mongoose
  .connect("mongodb://localhost:27017/myDemoDB", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then((result) => {
    app.listen(5000);
    console.log("Database connected");
  })
  .catch((err) => {
    console.log("cant connect", err);
  });

const homeFile=fs.readFileSync("index.html","utf-8");
const server=http.createServer((req,res)=>
{
    if(req.url=='/index.html')
    {
         fs.readFile("index.html","utf-8",(err,data)=>{
        console.log(data);
        res.end(data);
    });
}
    
}).listen(4000);