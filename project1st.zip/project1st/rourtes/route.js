const express = require("express");
const router = express.Router();
const productController = require("/booking");

router.get("/", productController.fetchAllProducts);

router.get("/booking/productId", productController.fetchProductById);
module.exports = router;